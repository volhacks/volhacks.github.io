## Demos and Closing Ceremony

#### Hey hackers! We hope you had a great weekend and built some great things! Here's a quick rundown of how closing ceremony will work. 

| Time  | Event  |  
|---|---|
| 8:30AM<br>(After Breakfast) | Head to DO416 🚶 |
| 9:00AM | Demos begin! Each team can present one hack for 3 minutes 💻📱⌚️ |
| 11:00AM | The Judges Confer 😱 (Music Jam)  |
| 11:30AM | Finalists demo again to our final judges |
| 12:00PM | MLH and sponsors award their prizes 🏆 |
| 12:15PM | Prizes are awarded for 1st, 2nd and 3rd place 🏅 |
| 12:30PM | Closing words from MLH and VolHacks 👋 |
